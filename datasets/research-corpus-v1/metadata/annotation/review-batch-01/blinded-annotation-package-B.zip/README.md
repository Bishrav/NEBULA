# NEBULA annotation package

This package contains one blinded annotation assignment. It contains the same
query-document pairs as the other assignment, but candidate order was shuffled
independently. Do not compare packages or share judgments. Do not add ranking
scores, retrieval ranks, source URLs, grounding IDs, or system guesses.

Status: HUMAN ANNOTATION REQUIRED. These files contain no pre-filled labels.
