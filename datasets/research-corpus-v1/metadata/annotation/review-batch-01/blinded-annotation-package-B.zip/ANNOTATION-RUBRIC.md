# NEBULA blinded relevance annotation rubric

Annotate each query-document pair independently. Do not infer the system that
retrieved the document. Assign one grade:

- 0 — Irrelevant: does not help answer the query.
- 1 — Useful context: related background, but does not substantially answer it.
- 2 — Substantially relevant: addresses an important part of the information need.
- 3 — Directly answers: gives an actionable, sufficiently specific answer.

Set uncertainty when the grade is difficult to determine. Use the evidence note
to briefly record the passage or reason supporting the grade. Do not add
personal information. Complete the timestamp when you submit the judgment.
